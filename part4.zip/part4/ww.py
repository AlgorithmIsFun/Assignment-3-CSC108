import pygame, sys, math

def distance(p1, p2):
    '''(tuple, tuple) -> double
    Return the distance between 2 points
    '''
    
    return math.sqrt(abs(p1[0]-p2[0])+abs(p1[1]-p2[1]))

class Actor:
    '''
    Represents an Actor in the game. Can be the Player, a Monster, boxes, wall.
    Any object in the game's grid that appears on the stage, and has an
    x- and y-coordinate.
    '''
    
    def __init__(self, icon_file, stage, x, y, delay=5):
        '''(Actor, str, Stage, int, int, int) -> None
        Given the name of an icon file (with the image for this Actor),
        the stage on which this Actor should appear, the x- and y-coordinates
        that it should appear on, and the speed with which it should
        update, construct an Actor object.
        '''
        
        self._icon = pygame.image.load(icon_file) # the image image to display of self
        self.set_position(x, y) # self's location on the stage
        self._stage = stage # the stage that self is on
        # the following can be used to change this Actors 'speed' relative to other
        # actors speed. See the delay method.
        self._delay = delay
        self._delay_count = 0
        self._test = 0
    
    def set_position(self, x, y):
        '''(Actor, int, int) -> None
        Set the position of this Actor to the given x- and y-coordinates.
        '''
        
        (self._x, self._y) = (x, y)

    def get_position(self):
        '''(Actor) -> tuple of two ints
        Return this Actor's x and y coordinates as a tuple.
        '''
        
        return (self._x, self._y)

    def get_icon(self):
        '''(Actor) -> pygame.Surface
        Return the image associated with this Actor.
        '''
        
        return self._icon

    def is_dead(self):
        '''(Actor) -> bool
        Return True iff this Actor is not alive.
        '''
        
        return False

    def move(self, other, dx, dy):
        '''(Actor, Actor, int, int) -> bool
        Other is an Actor telling us to move in direction (dx, dy). In this case, we just move.
        (dx,dy) is in {(1,1), (1,0), (1,-1), (0,1), (0,0), (0,-1), (-1,1), (-1,0), (-1,-1)}
    
        In the more general case, in subclasses, self will determine 
        if they will listen to other, and if so, will try to move in
        the specified direction. If the target space is occupied, then we 
        may have to ask the occupier to move.
        '''

        self.set_position(self._x + dx, self._y + dy)
        return True

    def delay(self):
        '''(Actor) -> bool
        Manage self's speed relative to other Actors. 
        Each time we get a chance to take a step, we delay. If our count wraps around to 0
        then we actually do something. Otherwise, we simply return from the step method.
        '''

        self._delay_count = (self._delay_count+1) % self._delay
        return self._delay_count == 0

    def step(self):
        '''(Actor) -> None
        Make the Actor take a single step in the animation of the game.
        self can ask the stage to help as well as ask other Actors
        to help us get our job done.
        '''

        pass

class Player(Actor):
    '''
    A Player is an Actor that can handle events. These typically come
    from the user, for example, key presses etc.
    '''

    def __init__(self, icon_file, stage, x=0, y=0):
        '''(Player, str, Stage, int, int) -> None
        Construct a Player with given image, on the given stage, at
        x- and y- position.
        '''
        
        super().__init__(icon_file, stage, x, y)
    
    def handle_event(self, event):
        '''(Player, int) -> None
        Used to register the occurrence of an event with self.
        '''
        
        pass

class KeyboardPlayer(Player):
    '''
    A KeyboardPlayer is a Player that can handle keypress events.
    '''
    
    def __init__(self, icon_file, stage, x=0, y=0):
        '''(KeyboardPlayer, str, Stage, int, int) -> None
        Construct a KeyboardPlayer. Other than the given Player information,
        a KeyboardPlayer also keeps track of the last key event that took place.
        '''
        
        super().__init__(icon_file, stage, x, y)
        self._last_event = None # we are only interested in the last event
    
    def handle_event(self, event):
        '''(KeyboardPlayer, int) -> None
        Record the last event directed at this KeyboardPlayer.
        All previous events are ignored.
        '''

        self._last_event = event

    def step(self):
        '''(KeyboardPlayer) -> None
        Take a single step in the animation. 
        For example: if the user asked us to move right, then we do that.
        '''

        #checks if a keyboard event occured
        if self._last_event is not None:
            dx, dy = 0, 0
            #checks if a certain index in a tuple does not equal 0
            if self._last_event[pygame.K_DOWN]:
                dy = 1
            if self._last_event[pygame.K_LEFT]:
                dx = -1
            if self._last_event[pygame.K_RIGHT]:
                dx = 1
            if self._last_event[pygame.K_UP]:
                dy = -1
            #checks if the player enters a movement command
            if dx is not None and dy is not None:
                self.move(self, dx, dy) # we are asking ourself to move
            self._last_event = None

    def move(self, other, dx, dy):
        '''(KeyboardPlayer, Actor, int, int) -> bool
        Move this Actor by dx and dy, if possible. other is the Actor that asked to make this move.
        If a move is possible (a space is available) then move to it and return True.
        If another Actor is occupying that space, ask that Actor to move to make space, and then
        move to that spot, if possible.
        If a move is not possible, then return False.
        '''

        # Where we are supposed to move.
        new_x = self._x + dx
        new_y = self._y + dy

        '''
        If (new_x, new_y) is on the stage, and is empty, then 
        we simply move there. Otherwise, we ask whomever is at (new_x, new_y)
        to move, also the same direction. If they moved, the space is now
        empty, so we now move into (new_x, new_y). If we successfully
        moved, then we return True, otherwise, we return False.
        checks if player is moving out of screen
        '''
        
        if not self._stage.is_in_bounds_x(new_x):
            new_x -= dx
        elif not self._stage.is_in_bounds_y(new_y):
            new_y -= dy  
        else:
            #checks if actor is in the way of player or player is not trying to move on itself (due to algorithm speed)
            if self._stage.get_actor(new_x, new_y) is not None and not isinstance(self._stage.get_actor(new_x, new_y), Player):
                #move actor in the way and checks if it is possible
                if self._stage.get_actor(new_x, new_y).move(other, dx, dy) is False:
                    return False
            #move player
            super().move(other, dx, dy)
            return True
        return False
        
class Box(Actor):
    '''
    A Box Actor.
    '''
    
    def __init__(self, icon_file, stage, x=0, y=0):
        '''(Box, str, Stage, int, int) -> None
        Construct a Box on the given stage, at given position.
        '''
        
        super().__init__(icon_file, stage, x, y)
    
    def move(self, other, dx, dy):
        '''(Box, Actor, int, int) -> bool
        Move this Actor by dx and dy, if possible. other is the Actor that asked to make this move.
        If a move is possible (a space is available) then move to it and return True.
        If another Actor is occupying that space, ask that Actor to move to make space, and then
        move to that spot, if possible.
        If a move is not possible, then return False.
        '''

        new_x = self._x + dx
        new_y = self._y + dy
        

        '''
        If (new_x, new_y) is on the stage, and is empty, then 
        we simply move there. Otherwise, we ask whomever is at (new_x, new_y)
        to move, also the same direction. If they moved, the space is now
        empty, so we now move into (new_x, new_y). If we successfully
        moved, then we return True, otherwise, we return False.
        checks if player is moving out of screen
        '''

        if not self._stage.is_in_bounds_x(new_x):
            new_x -= dx
        elif not self._stage.is_in_bounds_y(new_y):
            new_y -= dy
        else:
            #checks if actor is in the way of player or player is not trying to move on itself (due to algorithm speed)
            if self._stage.get_actor(new_x, new_y) is not None:
                #move actor in the way and checks if it is possible
                if self._stage.get_actor(new_x, new_y).move(other, dx, dy) is False:
                    return False
            #move box
            super().move(other, dx, dy)    
            return True
        return False
    
class Sticky_Box(Box):
    '''
    A Box Actor.
    '''
          
class Wall(Actor): 
    '''
    A Wall Actor.
    '''
    
    def __init__(self, icon_file, stage, x=0, y=0):
        '''(Wall, str, Stage, int, int) -> None
        Construct a Box on the given stage, at given position.
        '''

        super().__init__(icon_file, stage, x, y)
        
    def move(self, other, dx, dy):
        '''(Wall, Actor, int, int) -> bool
        Always return False so walls cannot move
        '''
        
        return False

class Monster(Actor):
    '''
    A Monster Actor
    '''
    
    def __init__(self, icon_file, stage, x=0, y=0, delay=5):
        '''(Monster, str, Stage, int, int, int) -> None
        Construct a Monster.
        '''
        
        super().__init__(icon_file, stage, x, y, delay)
        self._dx = 1
        self._dy = 1

    def step(self):
        '''(Monster) -> bool
        Take one step in the animation (this Monster moves by one space).
        If it's being delayed, return None. Else, return True.
        '''
        
        if not self.delay(): return 
        self.move(self, self._dx, self._dy)
        return True

    def move(self, other, dx, dy):
        '''(Monster, Actor, int, int) -> bool
        Move this Actor by dx and dy, if possible. other is the Actor that asked to make this move.
        If a move is possible (a space is available) then move to it and return True.
        If another Actor is occupying that space, or if that space is out of bounds,
        bounce back in the opposite direction.
        If a bounce back happened, then return False.
        '''
        
        if other != self: # Noone pushes me around
            return False
        bounce_off_edge = False
        self._dx = dx
        self._dy = dy
        new_x = self._x + self._dx
        new_y = self._y + self._dy
        #checks if monster is heading out of bounds
        if not self._stage.is_in_bounds_x(new_x): 
            self._dx=-self._dx
            bounce_off_edge=True
        if not self._stage.is_in_bounds_y(new_y):
            self._dy =- self._dy
            bounce_off_edge = True
        if bounce_off_edge: 
            return False
        #get actor where monster is heading
        actor = self._stage.get_actor(new_x, new_y)
        #checks if there is an actor where the monster is heading
        if actor != None:
            #checks if actor is a Player and kill the Player
            if isinstance(actor, Player):
               self._stage.remove_player()
               pygame.quit()
               sys.exit(0)
            #checks if actor is a sticky box and make monster not move
            elif isinstance(actor, Sticky_Box):
                return False
            #move monster in the opposite direction
            self._dx =- self._dx
            self._dy =- self._dy
            return False
        return super().move(other, dx, dy)

    def is_dead(self):
        '''(Monster) ->  bool
        Return whether this Monster has died.
        That is, if self is surrounded on all sides, by either Boxes or
        other Monsters.
        '''

       #loops all possible directions
        for i in range(-1, 2):
            for j in range(-1, 2):
                #checks if monster is surrounded by walls, boxes, player or boundary 
                if self._stage.get_actor(self._x + i, self._y + j) is None:
                    if self._stage.is_in_bounds(self._x + i, self._y + j):
                        return False             
        return True
    
class Camo_Monster(Monster):
    '''
    A Monster Actor
    '''
    
    def move(self, other, dx, dy):
        '''(Camo_Monster, Actor, int, int) -> bool
        Move this Actor by dx and dy, if possible. other is the Actor that asked to make this move.
        If a move is possible (a space is available) then move to it and return True.
        If another Actor is occupying that space, or if that space is out of bounds,
        bounce back in the opposite direction.
        If a bounce back happened, then return False.
        '''
        
        if other != self: # Noone pushes me around
            return False
        bounce_off_edge = False
        new_x = self._x + self._dx
        new_y = self._y + self._dy
        #checks if monster is heading out of bounds
        if not self._stage.is_in_bounds_x(new_x): 
            self._dx=-self._dx
            bounce_off_edge=True
        if not self._stage.is_in_bounds_y(new_y):
            self._dy =- self._dy
            bounce_off_edge = True
        if bounce_off_edge: 
            return False
        #get actor where monster is heading
        actor = self._stage.get_actor(new_x, new_y)
        #checks if there is an actor where the monster is heading
        if actor != None:
            #checks if actor is a Player and kill the Player
            if isinstance(actor, Player):
                self._stage.remove_player()
                pygame.quit()
                sys.exit(0)
            #checks if actor is a sticky box and make monster not move
            elif isinstance(actor, Sticky_Box):
                #plays shush sound once and camoflages monster into box
                if self._test == 0:
                    sound = pygame.mixer.Sound('icons/Shush.wav')
                    self._icon = pygame.image.load("icons/emblem-package-2-24.png")
                    sound.play()
                    self._test = 1
                return False
            #gives monster the ability to move other boxes and move opposite direction
            if self._stage.get_actor(new_x, new_y).move(other, dx, dy) is False:
                self._dx =- self._dx
                self._dy =- self._dy
                return False
            #changes back into monster and move opposite direction
            self._icon = pygame.image.load("icons/camo.png")
            self._test = 0
            self._dx =- self._dx
            self._dy =- self._dy
            super().move(other, dx, dy)
            return True
        super().move(other, dx, dy)
        return False
class Explode_Monster(Monster):
    '''
    A Monster Actor
    '''
    
    def is_dead(self):
        '''(Explode_Monster) -> None
        Return whether this Monster has died.
        That is, if self is surrounded on all sides, by either Boxes or
        other Monsters.'''

        #loops all possible directions
        for i in range(-1, 2):
            for j in range(-1, 2):
                #checks if monster is surrounded by walls, boxes, player or boundary 
                if self._stage.get_actor(self._x + i, self._y + j) is None:
                    if self._stage.is_in_bounds(self._x + i, self._y + j):
                        return False
        #plays explosive sound
        pygame.mixer.Sound('icons/Explosion.wav').play()
        #loops all possible directions
        for i in range(-1, 2):
            for j in range(-1, 2):
                if (i, j) != (0, 0):
                    #creates monster around explode monster
                    self._stage.remove_actor(self._stage.get_actor(self._x + i, self._y + j))
                    self._stage.add_actor(Monster("icons/face-devil-grin-24.png", self._stage, self._x + i, self._y + j, 3))
        return True

class Tracking_Monster(Monster):
    '''
    A Monster Actor
    '''
    
    def move(self, other, dx, dy):
        '''(Tracking_Monster, Actor, int, int) -> bool
        Move this Actor by dx and dy, if possible. other is the Actor that asked to make this move.
        If a move is possible (a space is available) then move to it and return True.
        If another Actor is occupying that space, or if that space is out of bounds,
        bounce back in the opposite direction.
        If a bounce back happened, then return False.
        '''
        
        dist = {}
        if other != self: # Noone pushes me around
            return False
        bounce_off_edge = False
        #decide which direction will lead closer to player
        for i in range(-1, 2):
            for j in range(-1, 2):
                if (i, j) == (0, 0):
                    pass
                elif self._stage.get_actor(self._x + i, self._y + j) is not None and not isinstance(self._stage.get_actor(self._x + i, self._y + j), KeyboardPlayer):
                    pass
                else:
                    dist[(i, j)] = distance((self._x + i, self._y + j), self._stage.get_player().get_position())
        #order dictionary from min distance to max distance
        w = min(dist.items(), key=lambda x: x[1])
        dx = w[0][0]
        dy = w[0][1]
        new_x = self._x + dx
        new_y = self._y + dy
        #checks if monster is heading out of bounds
        if not self._stage.is_in_bounds_x(new_x): 
            dx -= dx
            bounce_off_edge=True
        if not self._stage.is_in_bounds_y(new_y):
            dy -= dy
            bounce_off_edge = True
        if bounce_off_edge: 
            return False
        #get actor where monster is heading
        actor = self._stage.get_actor(new_x, new_y)
        #checks if there is an actor where the monster is heading
        if actor != None:
            #checks if actor is a Player and kill the Player
            if isinstance(actor, Player):
               self._stage.remove_player()
               pygame.quit()
               sys.exit(0)
            #checks if actor is a sticky box and make monster not move
            elif isinstance(actor, Sticky_Box):
                return False
            #move monster in the opposite direction
            dx -= dx
            dy -= dy
            return False
        return super().move(other, dx, dy)
class Stage:
    '''
    A Stage that holds all the game's Actors (Player, monsters, boxes, etc.).
    '''
    
    def __init__(self, width, height, icon_dimension):
        '''(Stage, int, int, int) -> None
        Construct a Stage with the given dimensions.
        '''

        #load pause font and background picture
        self._pause = False
        self._back = pygame.image.load('icons/back.png')
        self._smallText = pygame.font.Font("freesansbold.ttf",20)

        self._actors = [] # all actors on this stage (monsters, player, boxes, ...)
        self._player = None # a special actor, the player

        # the logical width and height of the stage
        self._width, self._height = width, height

        self._icon_dimension=icon_dimension # the pixel dimension of all actors
        # the pixel dimensions of the whole stage
        self._pixel_width = self._icon_dimension * self._width
        self._pixel_height = self._icon_dimension * self._height
        self._pixel_size = self._pixel_width, self._pixel_height

        # get a screen of the appropriate dimension to draw on
        self._screen = pygame.display.set_mode(self._pixel_size)

    def is_in_bounds(self, x, y):
        '''(Stage, int, int) -> bool
        Return True iff the position (x, y) falls within the dimensions of this Stage.
        '''
        
        return self.is_in_bounds_x(x) and self.is_in_bounds_y(y)

    def is_in_bounds_x(self, x):
        '''(Stage, int) -> bool
        Return True iff the x-coordinate given falls within the width of this Stage.
        '''
        
        return 0 <= x and x < self._width

    def is_in_bounds_y(self, y):
        '''(Stage, int) -> bool
        Return True iff the y-coordinate given falls within the height of this Stage.
        '''

        return 0 <= y and y < self._height

    def get_width(self):
        '''(Stage) -> int
        Return width of Stage.
        '''

        return self._width

    def get_height(self):
        '''(Stage) -> int
        Return height of Stage.
        '''
        
        return self._height

    def set_player(self, player):
        '''(Stage, Player) -> None
        A Player is a special actor, store a reference to this Player in the attribute
        self._player, and add the Player to the list of Actors.
        '''
        
        self._player=player
        self.add_actor(self._player)

    def get_player(self):
        '''(Stage) -> Actor or None
        Return the Player.
        Or, return None if there is no Player in that position.
        '''
        
        for a in self._actors:
            if isinstance(a, KeyboardPlayer):
                return a

    def remove_player(self):
        '''(Stage) -> None
        Remove the Player from the Stage.
        '''
        
        self.remove_actor(self._player)
        self._player=None
        print('Game Over! You Lost')

    def player_event(self, event):
        '''(Stage, int) -> None
        Send a user event to the player (this is a special Actor).
        '''
        
        self._player.handle_event(event)

    def add_actor(self, actor):
        '''(Stage, Actor) -> None
        Add the given actor to the Stage.
        '''

        self._actors.append(actor)

    def remove_actor(self, actor):
        '''(Stage, Actor) -> None
        Remove the given actor from the Stage.
        '''
        
        self._actors.remove(actor)

    def step(self):
        '''(Stage) -> None
        Take one step in the animation of the game. 
        Do this by asking each of the actors on this Stage to take a single step.
        '''

        for a in self._actors:
            a.step()

    def get_actors(self):
        '''(Stage) -> None
        Return the list of Actors on this Stage.
        '''
        
        return self._actors

    def get_actor(self, x, y):
        '''(Stage, int, int) -> Actor or None
        Return the first actor at coordinates (x,y).
        Or, return None if there is no Actor in that position.
        '''
        
        for a in self._actors:
            if a.get_position() == (x,y):
                return a
        return None

    def draw(self):
        '''(Stage) -> None
        Draw all Actors that are part of this Stage to the screen.
        '''

        remaining_enemies = 0
        #add background picture
        self._screen.blit(self._back, self._back.get_rect()) # (0,0,0)=(r,g,b)=black
        for a in self._actors:
            if isinstance(a, Monster):
                remaining_enemies += 1
                #checks if monster is dead
                if a.is_dead():
                    self._actors.remove(a)
                else:
                    icon = a.get_icon()
                    (x,y) = a.get_position()
                    d = self._icon_dimension
                    rect = pygame.Rect(x*d, y*d, d, d)
                    self._screen.blit(icon, rect)
            else:
                icon = a.get_icon()
                (x,y) = a.get_position()
                d = self._icon_dimension
                rect = pygame.Rect(x*d, y*d, d, d)
                self._screen.blit(icon, rect)
        if not remaining_enemies:
            print('Congratulations! You Won')
            pygame.quit()
            sys.exit(0)
        #assign if and where mouse is clicked
        click = pygame.mouse.get_pressed()
        mouse = pygame.mouse.get_pos()
        #create pause button
        textSurf = self._smallText.render('PAUSE', True, (255, 255, 255))
        #loops untill player clicks continue
        while self._pause:
            click = pygame.mouse.get_pressed()
            mouse = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                #checks if player clicked at right spot
                if 300 > mouse[0] > 150 and 550 > mouse[1] > 400:
                    if click[0] == 1:
                        self._pause = False
        #checks if player clicked at right spot
        if 130 > mouse[0] > 0 and 550 > mouse[1] > 400:  
            if click[0] == 1:
                self._pause = True
                textSurf = self._smallText.render('CONTINUE', True, (255, 255, 255))
        #changes location of pause/continue button
        if self._pause:
            self._screen.blit(textSurf, (150, 450))
        else:
            self._screen.blit(textSurf, (0, 450))
        pygame.display.flip()
