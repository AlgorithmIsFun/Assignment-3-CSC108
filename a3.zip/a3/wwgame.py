import sys, pygame, random
from ww import *

pygame.init()
#assign Stage class
ww=Stage(20, 20, 24)
#adds players, walls and monsters
ww.set_player(KeyboardPlayer("icons/face-cool-24.png", ww))
ww.add_actor(Wall("icons/wall.jpg", ww, 3, 4))
ww.add_actor(Wall("icons/wall.jpg", ww, 4, 4))
ww.add_actor(Wall("icons/wall.jpg", ww, 5, 4))
ww.add_actor(Wall("icons/wall.jpg", ww, 13, 4))
ww.add_actor(Wall("icons/wall.jpg", ww, 14, 4))
ww.add_actor(Wall("icons/wall.jpg", ww, 8, 10))
ww.add_actor(Wall("icons/wall.jpg", ww, 8, 11))
ww.add_actor(Monster("icons/face-devil-grin-24.png", ww, 0, 3, 1))
ww.add_actor(Monster("icons/face-devil-grin-24.png", ww, 7, 4, 5))
ww.add_actor(Monster("icons/face-devil-grin-24.png", ww, 4, 10, 3))
ww.add_actor(Monster("icons/face-devil-grin-24.png", ww, 5, 20, 2))

# picks a random x and y coordinate and checks if there is an actor there
# at that coordinate. If not, then it places a box at that position
num_boxes = 0
while num_boxes < 95:
    x = random.randrange(ww.get_width())
    y = random.randrange(ww.get_height())
    if ww.get_actor(x,y) is None:
        ww.add_actor(Box("icons/emblem-package-2-24.png", ww, x, y))
        num_boxes += 1
num_boxes = 0
while num_boxes < 5:
    x = random.randrange(ww.get_width())
    y = random.randrange(ww.get_height())
    if ww.get_actor(x,y) is None:
        ww.add_actor(Sticky_Box("icons/sticky.jpg", ww, x, y))
        num_boxes += 1

#re-draws the board based on them presssing certain buttons and
#based on enemies movement from the step function
while True:
    pygame.time.delay(100)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit(0)
        if event.type == pygame.KEYDOWN:
            ww.player_event(pygame.key.get_pressed())
    ww.step()
    ww.draw()
